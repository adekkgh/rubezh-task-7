﻿using Microsoft.AspNetCore.Mvc;
using ProductModel.Models;
using OnLineShop.DB.Models;
using OnLineShop.DB;
using ProductModel.Helpers;
using System.IO;
using System;
using System.Threading.Tasks;
using System.Linq;
using Microsoft.AspNetCore.Hosting;

namespace ProductModel.Controllers
{
    public class AdminController : Controller
    {
        public readonly IGetProducts RepositoryProductDBs;
        private readonly IWebHostEnvironment webHostEnvironment;

        public AdminController(IGetProducts list_ProductDBs, IWebHostEnvironment webHostEnvironment)
        {
            this.RepositoryProductDBs = list_ProductDBs;
            this.webHostEnvironment = webHostEnvironment;
        }

        public IActionResult Orders()
        {
            return View();
        }

        public IActionResult Users()
        {
            return View();
        }

        public IActionResult Roles()
        {
            return View();
        }

        public IActionResult Products()
        {

            return View(Mapping.ListProductDBToListProduct(RepositoryProductDBs.GetProducts()));
        }

        public IActionResult AddProduct()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddProduct(Product product)
        {
            // если не прошел валидацию возвращаем на ту же вьюшку для редактирования
            if (!ModelState.IsValid)
            {
                return View(product);
            }
            if(product.uploadedImages != null)
            {
                var productImagePath = Path.Combine(webHostEnvironment.WebRootPath + "/images/products/");
                if (!Directory.Exists(productImagePath))
                {
                    Directory.CreateDirectory(productImagePath);
                }

                var fileName = Guid.NewGuid().ToString() + "." + product.uploadedImages.FileName.Split('.').Last();
                using (var fileStream = new FileStream(productImagePath +  fileName, FileMode.Create))
                {
                    product.uploadedImages.CopyTo(fileStream);
                }
            }

            // тут сохранить продукт в product DB
            RepositoryProductDBs.Add(Mapping.ProductToProductDB(product));
            return RedirectToAction("Index", "Product");
        }
    }

}
