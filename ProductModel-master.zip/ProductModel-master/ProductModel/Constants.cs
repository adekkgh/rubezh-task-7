﻿using ProductModel.Models;

namespace ProductModel
{
    public class Constants
    {
        public static User MD = new User("MD");
    }
}
